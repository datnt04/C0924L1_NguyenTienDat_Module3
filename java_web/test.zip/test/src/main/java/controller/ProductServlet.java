package controller;

import model.Product;
import service.ProductService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private ProductService productService;

    @Override
    public void init() throws ServletException {
        productService = new ProductService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("🌀 [ProductServlet] doGet called");

        String searchQuery = request.getParameter("search");
        List<Product> productList;

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            productList = productService.searchProducts(searchQuery);
        } else {
            productList = productService.getAllBooks();
        }

        if (productList == null) {
            System.out.println("❌ [ProductServlet] productList is null");
        } else {
            System.out.println("✅ [ProductServlet] productList size: " + productList.size());
        }

        request.setAttribute("productList", productList);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}

